from django.apps import AppConfig


class NewspaperappConfig(AppConfig):
    name = 'NewspaperApp'
